/* ════════════════════════════════════════
   routes/auth.js
   POST /api/auth/login  — login do admin
════════════════════════════════════════ */
const express = require('express');
const jwt     = require('jsonwebtoken');
const db      = require('../db/database');

const router = express.Router();

router.post('/login', (req, res) => {
  const { email, password } = req.body;

  // Credenciais do admin vêm do .env
  if (
    email    !== process.env.ADMIN_EMAIL ||
    password !== process.env.ADMIN_PASSWORD
  ) {
    // Log tentativa falha
    db.prepare(`
      INSERT INTO admin_logs (action, details, ip)
      VALUES ('login_failed', ?, ?)
    `).run(`Tentativa com email: ${email}`, req.ip);

    return res.status(401).json({ error: 'Credenciais inválidas' });
  }

  const token = jwt.sign(
    { role: 'admin', email },
    process.env.JWT_SECRET,
    { expiresIn: '8h' }
  );

  // Log sucesso
  db.prepare(`
    INSERT INTO admin_logs (action, details, ip)
    VALUES ('login_success', ?, ?)
  `).run(`Admin logado: ${email}`, req.ip);

  res.json({ token, expiresIn: '8h' });
});

module.exports = router;
