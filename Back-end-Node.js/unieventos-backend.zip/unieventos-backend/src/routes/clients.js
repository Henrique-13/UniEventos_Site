/* ════════════════════════════════════════
   routes/clients.js
   Rotas de clientes (todas protegidas por JWT)

   GET    /api/clients           — lista todos
   GET    /api/clients/:id       — detalhe + reservas
   POST   /api/clients/register  — cadastro pelo front (público)
   DELETE /api/clients/:id       — remove (admin)
════════════════════════════════════════ */
const express = require('express');
const bcrypt  = require('bcryptjs');
const db      = require('../db/database');
const auth    = require('../middleware/auth');

const router = express.Router();

/* ── Cadastro público (chamado pelo front quando faz reserva) ── */
router.post('/register', (req, res) => {
  const { name, email, phone, password } = req.body;

  if (!name || !email || !password)
    return res.status(400).json({ error: 'name, email e password são obrigatórios' });

  // Verifica se email já existe
  const existing = db.prepare('SELECT id FROM clients WHERE email = ?').get(email);
  if (existing)
    return res.status(409).json({ error: 'E-mail já cadastrado', clientId: existing.id });

  const hash = bcrypt.hashSync(password, 10);
  const stmt = db.prepare(`
    INSERT INTO clients (name, email, phone, password)
    VALUES (?, ?, ?, ?)
  `);

  try {
    const info = stmt.run(name, email, phone || null, hash);
    res.status(201).json({ id: info.lastInsertRowid, name, email });
  } catch (err) {
    res.status(500).json({ error: 'Erro ao cadastrar cliente' });
  }
});

/* ── Login do cliente (retorna token) ── */
router.post('/login', (req, res) => {
  const { email, password } = req.body;
  const client = db.prepare('SELECT * FROM clients WHERE email = ?').get(email);

  if (!client || !bcrypt.compareSync(password, client.password))
    return res.status(401).json({ error: 'Credenciais inválidas' });

  // Atualiza last_login
  db.prepare("UPDATE clients SET last_login = datetime('now','localtime') WHERE id = ?")
    .run(client.id);

  const jwt = require('jsonwebtoken');
  const token = jwt.sign(
    { role: 'client', id: client.id, email: client.email },
    process.env.JWT_SECRET,
    { expiresIn: '24h' }
  );

  res.json({ token, client: { id: client.id, name: client.name, email: client.email } });
});

/* ── Lista todos os clientes (admin) ── */
router.get('/', auth, (req, res) => {
  const clients = db.prepare(`
    SELECT
      c.id, c.name, c.email, c.phone, c.created_at, c.last_login,
      COUNT(b.id) AS total_bookings,
      COALESCE(SUM(b.total_price), 0) AS total_spent
    FROM clients c
    LEFT JOIN bookings b ON b.client_id = c.id
    GROUP BY c.id
    ORDER BY c.created_at DESC
  `).all();

  res.json(clients);
});

/* ── Detalhe de um cliente + suas reservas (admin) ── */
router.get('/:id', auth, (req, res) => {
  const client = db.prepare(
    'SELECT id, name, email, phone, created_at, last_login FROM clients WHERE id = ?'
  ).get(req.params.id);

  if (!client) return res.status(404).json({ error: 'Cliente não encontrado' });

  const bookings = db.prepare(
    'SELECT * FROM bookings WHERE client_id = ? ORDER BY created_at DESC'
  ).all(req.params.id);

  res.json({ ...client, bookings });
});

/* ── Remove cliente (admin) ── */
router.delete('/:id', auth, (req, res) => {
  const info = db.prepare('DELETE FROM clients WHERE id = ?').run(req.params.id);
  if (info.changes === 0) return res.status(404).json({ error: 'Cliente não encontrado' });

  db.prepare("INSERT INTO admin_logs (action, details) VALUES ('client_deleted', ?)")
    .run(`Cliente ID ${req.params.id} removido`);

  res.json({ success: true });
});

module.exports = router;
