/* ════════════════════════════════════════
   routes/bookings.js
   Rotas de reservas

   POST /api/bookings          — cria reserva (público, chamado pelo checkout.js)
   GET  /api/bookings          — lista todas (admin)
   GET  /api/bookings/:orderId — detalhe por order_id (admin)
   PUT  /api/bookings/:orderId/cancel — cancela (admin)
════════════════════════════════════════ */
const express = require('express');
const db      = require('../db/database');
const auth    = require('../middleware/auth');

const router = express.Router();

/* ── Criar reserva (chamado pelo front após confirmação do MP sandbox) ── */
router.post('/', (req, res) => {
  const {
    order_id, client_name, client_email, client_phone,
    package_key, package_name,
    stadium, sector, gate, event_date,
    quantity, unit_price, total_price,
    payment_method,
    // Se cliente já tem conta, passa client_id; senão, deixa null
    client_id
  } = req.body;

  // Validação mínima
  if (!order_id || !client_email || !package_key || !quantity)
    return res.status(400).json({ error: 'Campos obrigatórios faltando' });

  // Se não tiver client_id mas tiver e-mail, tenta encontrar o cliente
  let resolvedClientId = client_id || null;
  if (!resolvedClientId && client_email) {
    const found = db.prepare('SELECT id FROM clients WHERE email = ?').get(client_email);
    if (found) resolvedClientId = found.id;
  }

  try {
    const info = db.prepare(`
      INSERT INTO bookings
        (order_id, client_id, client_name, client_email,
         package_key, package_name, stadium, sector, gate, event_date,
         quantity, unit_price, total_price, payment_method)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      order_id, resolvedClientId, client_name, client_email,
      package_key, package_name, stadium, sector, gate, event_date,
      quantity, unit_price, total_price, payment_method
    );

    res.status(201).json({ id: info.lastInsertRowid, order_id, status: 'confirmed' });
  } catch (err) {
    if (err.message.includes('UNIQUE')) {
      return res.status(409).json({ error: 'order_id já existe' });
    }
    res.status(500).json({ error: 'Erro ao salvar reserva' });
  }
});

/* ── Lista todas as reservas (admin) ── */
router.get('/', auth, (req, res) => {
  const { status, package_key, from, to } = req.query;

  let query = 'SELECT * FROM bookings WHERE 1=1';
  const params = [];

  if (status)      { query += ' AND status = ?';       params.push(status); }
  if (package_key) { query += ' AND package_key = ?';  params.push(package_key); }
  if (from)        { query += ' AND created_at >= ?';  params.push(from); }
  if (to)          { query += ' AND created_at <= ?';  params.push(to); }

  query += ' ORDER BY created_at DESC';

  const bookings = db.prepare(query).all(...params);
  res.json(bookings);
});

/* ── Estatísticas (admin) ── */
router.get('/stats', auth, (req, res) => {
  const stats = db.prepare(`
    SELECT
      COUNT(*)                                   AS total_bookings,
      SUM(total_price)                           AS total_revenue,
      AVG(total_price)                           AS avg_ticket,
      SUM(CASE WHEN status='confirmed' THEN 1 ELSE 0 END) AS confirmed,
      SUM(CASE WHEN status='cancelled' THEN 1 ELSE 0 END) AS cancelled,
      SUM(quantity)                              AS total_tickets
    FROM bookings
  `).get();

  const byPackage = db.prepare(`
    SELECT package_name, COUNT(*) as count, SUM(total_price) as revenue
    FROM bookings GROUP BY package_key
  `).all();

  const byMonth = db.prepare(`
    SELECT strftime('%Y-%m', created_at) AS month,
           COUNT(*) AS count, SUM(total_price) AS revenue
    FROM bookings GROUP BY month ORDER BY month DESC LIMIT 12
  `).all();

  res.json({ ...stats, byPackage, byMonth });
});

/* ── Detalhe de 1 reserva por order_id (admin) ── */
router.get('/:orderId', auth, (req, res) => {
  const booking = db.prepare(
    'SELECT * FROM bookings WHERE order_id = ?'
  ).get(req.params.orderId);

  if (!booking) return res.status(404).json({ error: 'Reserva não encontrada' });
  res.json(booking);
});

/* ── Cancelar reserva (admin) ── */
router.put('/:orderId/cancel', auth, (req, res) => {
  const info = db.prepare(
    "UPDATE bookings SET status = 'cancelled' WHERE order_id = ?"
  ).run(req.params.orderId);

  if (info.changes === 0) return res.status(404).json({ error: 'Reserva não encontrada' });

  db.prepare("INSERT INTO admin_logs (action, details) VALUES ('booking_cancelled', ?)")
    .run(`Reserva ${req.params.orderId} cancelada`);

  res.json({ success: true, order_id: req.params.orderId, status: 'cancelled' });
});

module.exports = router;
