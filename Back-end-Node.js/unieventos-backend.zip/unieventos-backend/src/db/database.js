/* ════════════════════════════════════════
   db/database.js
   Inicializa o banco SQLite e cria as tabelas
════════════════════════════════════════ */
const Database = require('better-sqlite3');
const path = require('path');

const DB_PATH = path.join(__dirname, '../../data/unieventos.db');

// Garante que a pasta /data existe
const fs = require('fs');
const dataDir = path.join(__dirname, '../../data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const db = new Database(DB_PATH);

// Ativa WAL para melhor performance em leituras simultâneas
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

/* ─── CRIAÇÃO DAS TABELAS ─── */
db.exec(`
  /* Clientes cadastrados */
  CREATE TABLE IF NOT EXISTS clients (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT    NOT NULL,
    email       TEXT    NOT NULL UNIQUE,
    phone       TEXT,
    password    TEXT    NOT NULL,         -- hash bcrypt
    created_at  TEXT    DEFAULT (datetime('now','localtime')),
    last_login  TEXT
  );

  /* Reservas (cada linha = 1 pedido) */
  CREATE TABLE IF NOT EXISTS bookings (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id      TEXT    NOT NULL UNIQUE,   -- "UE-XXXXX"
    client_id     INTEGER REFERENCES clients(id),
    client_name   TEXT    NOT NULL,
    client_email  TEXT    NOT NULL,
    package_key   TEXT    NOT NULL,          -- basico | premium | vip
    package_name  TEXT    NOT NULL,
    stadium       TEXT    NOT NULL,
    sector        TEXT    NOT NULL,
    gate          TEXT    NOT NULL,
    event_date    TEXT    NOT NULL,
    quantity      INTEGER NOT NULL,
    unit_price    REAL    NOT NULL,
    total_price   REAL    NOT NULL,
    payment_method TEXT   NOT NULL,
    status        TEXT    DEFAULT 'confirmed', -- confirmed | cancelled
    created_at    TEXT    DEFAULT (datetime('now','localtime'))
  );

  /* Log de acesso ao painel admin */
  CREATE TABLE IF NOT EXISTS admin_logs (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    action     TEXT    NOT NULL,
    details    TEXT,
    ip         TEXT,
    created_at TEXT    DEFAULT (datetime('now','localtime'))
  );
`);

module.exports = db;
